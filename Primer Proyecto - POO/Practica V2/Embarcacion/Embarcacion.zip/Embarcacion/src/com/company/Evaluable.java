package com.company;

public interface Evaluable {

    public boolean esGrande();

}
